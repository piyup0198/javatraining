package com.training.springmvc.controllar.dao;

import java.util.List;

import com.training.springmvc.controllar.model.User;


public interface UserDao {
	List<User> getUsers();

}
