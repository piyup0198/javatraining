package com.training.springmvc.service;


import com.training.springmvc.controllar.model.Book;

public interface BookService {

	boolean createBook(Book book);


}
